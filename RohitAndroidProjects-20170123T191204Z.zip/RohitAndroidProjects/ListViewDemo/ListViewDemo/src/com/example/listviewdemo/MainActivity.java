package com.example.listviewdemo;

import java.util.ArrayList;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class MainActivity extends Activity {

	protected static final String TAG = "MainActivity";
	private ListView listView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		listView = (ListView) findViewById(R.id.listView);
		final ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("aaaa");
		arrayList.add("bbbb");
		arrayList.add("cccc");
		arrayList.add("dddd");
		arrayList.add("eeee");
		arrayList.add("ffff");
		arrayList.add("gggg");
		arrayList.add("hhhh");
		arrayList.add("aaaa*");
		arrayList.add("bbbb*");
		arrayList.add("cccc*");
		arrayList.add("dddd*");
		arrayList.add("eeee*");
		arrayList.add("ffff*");
		arrayList.add("gggg*");
		arrayList.add("hhhh*");
		
		/*ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, 
				android.R.layout.simple_list_item_1, arrayList);*/
		
		MyAdapter myAdapter = new MyAdapter(this, R.layout.list_item, arrayList);
		
		listView.setAdapter(myAdapter);
		
		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				Log.d(TAG, "arg2="+arg2);
				Log.e(TAG, "arg3="+arg3);
				Log.w(TAG, "value="+arrayList.get(arg2));
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
