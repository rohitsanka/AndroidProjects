package com.example.xmlparssax2;

public class Book {
	private String bookID;
	private String author;
	private String title;
	private String genre;
	private Double price;
	private String publish_date;
	private String description;
	public String getBookID() {
		return bookID;
	}
	public void setBookID(String bookID) {
		this.bookID = bookID;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getPublish_date() {
		return publish_date;
	}
	public void setPublish_date(String publish_date) {
		this.publish_date = publish_date;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public String getDetails() {
		String result= bookID+"\n"+author+"\n"+title+"\n"+genre+"\n"+price+"\n"+publish_date+"\n"+description;
		return result;
	}
	@Override
	public String toString() {
		
		return bookID + ": " + title;
	}
	
	
}
