package com.example.xmlparssax2;

import java.util.ArrayList;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SAXXMLHandler extends DefaultHandler {
	
	private List<Book> bookList;
	private String tempVal;
	private Book tempBook;
	
	public SAXXMLHandler() {
	 bookList = new ArrayList<Book>();
	}
	public List<Book> getBook()
	{
		return bookList;
	}
	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attributes) throws SAXException {
		 
		tempVal="";
		if(qName.equalsIgnoreCase("book"))
		{
			tempBook= new Book();
			
			//tempBook.setBookID(bookID)
			//tempBook.setId(parser.getAttributeValue(null, "id"));
		}
	}
	@Override
	public void characters(char[] ch, int start, int length)
			throws SAXException {
		
		tempVal=new String(ch,start,length);
	}
	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		
		if(qName.equalsIgnoreCase("book"))
		{
			bookList.add(tempBook);
		}
		else if (qName.equalsIgnoreCase("author")) 
		{
			tempBook.setAuthor(tempVal);
		}
		else if (qName.equalsIgnoreCase("title")) 
		{
			tempBook.setTitle(tempVal);
		}
		else if (qName.equalsIgnoreCase("genre")) 
		{
			tempBook.setGenre(tempVal);
		}
		else if (qName.equalsIgnoreCase("price")) 
		{
			tempBook.setPrice(Double.parseDouble(tempVal));
		}
		else if (qName.equalsIgnoreCase("publish_date")) 
		{
			tempBook.setPublish_date(tempVal);
		}
		else if (qName.equalsIgnoreCase("description")) 
		{
			tempBook.setDescription(tempVal);
		}
	}
}
		
		
		
	
	
	
	
	
