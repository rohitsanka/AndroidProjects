package com.example.xmlparssax2;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;

public class SAXXMLParser {
	
	public static List<Book> parse(InputStream is)
	{
		List<Book> bookList = null;
		try {
			XMLReader xmlReader = SAXParserFactory.newInstance().newSAXParser().getXMLReader();
			SAXXMLHandler saxHandler = new SAXXMLHandler();
			xmlReader.setContentHandler(saxHandler);
			xmlReader.parse(new InputSource(is));
			bookList=saxHandler.getBook();
			
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bookList;
		
	}

}
