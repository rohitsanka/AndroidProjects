package com.example.xmlparsingproject2;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

public class XMLPullParserHandler {
	 List<Book> books;
	    private Book book;
	    private String text;
	 
	    public XMLPullParserHandler() {
	        books = new ArrayList<Book>();
	    }
	 
	
	    public List<Book> parse(InputStream is) {
	        XmlPullParserFactory factory = null;
	        XmlPullParser parser = null;
	        try {
	            factory = XmlPullParserFactory.newInstance();
	            factory.setNamespaceAware(true);
	            parser = factory.newPullParser();
	 
	            parser.setInput(is, null);
	 
	            int eventType = parser.getEventType();
	            while (eventType != XmlPullParser.END_DOCUMENT) {
	                String tagname = parser.getName();
	                switch (eventType) {
	                case XmlPullParser.START_TAG:
	                    if (tagname.equalsIgnoreCase("book")) {
	                        // create a new instance of book
	                        book = new Book();
	                        book.setId(parser.getAttributeValue(null, "id"));
	                    }
	                    break;
	 
	                case XmlPullParser.TEXT:
	                    text = parser.getText();
	                    break;
	 
	                case XmlPullParser.END_TAG:
	                    if (tagname.equalsIgnoreCase("book")) {
	                        // add employee object to list
	                        books.add(book);
	                    } else if (tagname.equalsIgnoreCase("author")) {
	                        book.setAuthor(text);
	                    } else if (tagname.equalsIgnoreCase("title")) {
	                    	book.setTitle(text);
	                    } else if (tagname.equalsIgnoreCase("genre")) {
	                        book.setGenre(text);
	                    } else if (tagname.equalsIgnoreCase("price")) {
	                        book.setPrice(Double.parseDouble(text));
	                    } else if (tagname.equalsIgnoreCase("publish_date")) {
	                        book.setPublish_date(text);
	                    }else if (tagname.equalsIgnoreCase("description")) {
	                        book.setDescription(text);
	                    }
	                        
	                    break;
	 
	                default:
	                    break;
	                }
	                eventType = parser.next();
	            }
	 
	        } catch (XmlPullParserException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	 
	        return books;
	    }

}
