package com.example.widgetprojectforseconds;

import android.appwidget.AppWidgetManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.widget.RemoteViews;

public class AlarmManagerBroadcastReceiver extends BroadcastReceiver {

	@Override
	public void onReceive(Context context, Intent intent) {
		
		System.out.println(" inside onReceive ");
		
		
		PowerManager pm = (PowerManager) context.getSystemService(Context.POWER_SERVICE);
		
		PowerManager.WakeLock wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "YOUR TAG");
		
		wl.acquire();
		
		RemoteViews remoteViews = new RemoteViews(context.getPackageName(), R.layout.timewidgetlayout);
		
		remoteViews.setTextViewText(R.id.tvTime, Utility.getCurrentTime("hh:mm:ss a"));
		
		ComponentName thiswidget = new ComponentName(context, TimeWidgetProvider.class);
		
		AppWidgetManager manager = AppWidgetManager.getInstance(context);
		
		manager.updateAppWidget(thiswidget, remoteViews);
		
		System.out.println("onReceive Executed");
		
		 wl.release();

	}

}
