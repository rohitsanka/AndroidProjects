package com.example.widgetprojectforseconds;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Utility {
	
	public static String getCurrentTime(String timeformat){
		
		System.out.println(" inside getCurrentTime ");
		      Format formatter = new SimpleDateFormat(timeformat);
		      
		      System.out.println("setting current time ");
		          return formatter.format(new Date());
	}


}
