package com.example.widgetprojectforseconds;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.RemoteViews;
import android.widget.Toast;

public class TimeWidgetProvider extends AppWidgetProvider {

	@Override
	public void onDeleted(Context context, int[] appWidgetIds) {
		
		Toast.makeText(context, "TimeWidgetRemoved id(s):"+appWidgetIds, Toast.LENGTH_SHORT).show();
		
		System.out.println("onDeleted Executed");

		super.onDeleted(context, appWidgetIds);
	}

	@Override
	public void onDisabled(Context context) {
		
		Toast.makeText(context, "onDisabled():last widget instance removed", Toast.LENGTH_SHORT).show();
		
		 Intent intent = new Intent(context, AlarmManagerBroadcastReceiver.class);
		 
		 PendingIntent sender = PendingIntent.getBroadcast(context, 0, intent, 0);
		 
		 AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
		 
		 alarmManager.cancel(sender);
		 
		 System.out.println("onDisabled Executed");

		super.onDisabled(context);
	}

	@Override
	public void onEnabled(Context context) {
		
		System.out.println(" inside onEnabled ");
		
		super.onEnabled(context);
		
		AlarmManager am=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
		/*This class provides access to the system alarm services.
		 *  These allow you to schedule your application to be run at some point in the future.
		 *   When an alarm goes off, the Intent that had been registered for it is broadcast by the system, 
		 *   automatically starting the target application if it is not already running.
		 *    Registered alarms are retained while the device is asleep 
		 *    (and can optionally wake the device up if they go off during that time),
		 *     but will be cleared if it is turned off and rebooted. 


		*/
		Intent intent = new Intent(context, AlarmManagerBroadcastReceiver.class);
		
		PendingIntent pi = PendingIntent.getBroadcast(context, 0, intent, 0);
		
		/* A description of an Intent and target action to perform with it. 
		 * Instances of this class are created with getActivity(Context, int, Intent, int), 
		 * getActivities(Context, int, Intent[], int), getBroadcast(Context, int, Intent, int),
		 *  and getService(Context, int, Intent, int); 
		 *  the returned object can be handed to other applications so that they can perform the action 
		 *  you described on your behalf at a later time. 

  */
		
		am.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()+ 100 * 3, 1000 , pi);
		
		 System.out.println("onEnabled Executed");
		
	}

	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
			int[] appWidgetIds) {
		
		System.out.println(" inside onUpdate ");
		
		ComponentName thisWidget = new ComponentName(context,TimeWidgetProvider.class);
		
		for (int widgetId : appWidgetManager.getAppWidgetIds(thisWidget)) 
		{
			RemoteViews remoteViews = new RemoteViews(context.getPackageName(),R.layout.timewidgetlayout);
			
			remoteViews.setTextViewText(R.id.tvTime, Utility.getCurrentTime("hh:mm:ss a"));
			
			appWidgetManager.updateAppWidget(widgetId, remoteViews);
			
			System.out.println("onUpdate Executed");
			
		}
	}

	@Override
	public void onAppWidgetOptionsChanged(Context context,
			AppWidgetManager appWidgetManager, int appWidgetId,
			Bundle newOptions) {
		
		Toast.makeText(context, "onAppWidgetOptionsChanged() called", Toast.LENGTH_SHORT).show();
		
		System.out.println("onAppWidgetOptionsChanged Executed");
		
		
	}
	

}
