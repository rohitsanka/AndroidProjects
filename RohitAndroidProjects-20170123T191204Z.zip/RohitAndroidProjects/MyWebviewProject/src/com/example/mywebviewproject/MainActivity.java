package com.example.mywebviewproject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {
	
	private EditText field;
	private WebView browser;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		field = (EditText) findViewById(R.id.urlField);
		browser = (WebView) findViewById(R.id.webView1);
		browser.setWebViewClient(new MyBrowser());
	}
	
	public void open(View view)
	{
		String url  =field.getText().toString();
		browser.getSettings().setLoadsImagesAutomatically(true);
		browser.getSettings().setJavaScriptEnabled(true);
		browser.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		browser.loadUrl(url);
	}
	
	public void openFromAsset(View view)
	{
		String url  ="file:///android_asset/myHtml.html"; 
		browser.getSettings().setLoadsImagesAutomatically(true);
		browser.getSettings().setJavaScriptEnabled(true);
		browser.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		browser.loadUrl(url);
	}
	

	
	public void openForExternalStorage(View view)
	{
		browser.getSettings().setLoadsImagesAutomatically(true);
		browser.getSettings().setJavaScriptEnabled(true);
		browser.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)){
			
			System.out.println("NO SD CARD");
       
			Log.d("tag", "No SDCARD");
} else {
	
	System.out.println("SD CARD AVAILABLE");
	browser.loadUrl("file:///sdcard/myHtmlExtSD.html");
	
}
		
	}


}
