package com.example.myviewpagerproject;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class ViewPagerAdapter extends PagerAdapter {
	
	    private Context context;
	    private String[] rank;
	    private String[] country;
	    private String[] population;
	    private int[] flag;
	    private LayoutInflater inflater;
	    
	    static int count;
	    
	    public ViewPagerAdapter(Context context, String[] rank, String[] country,
	            String[] population, int[] flag) {
	        this.context = context;
	        this.rank = rank;
	        this.country = country;
	        this.population = population;
	        this.flag = flag;
	        
	        System.out.println("ViewPagerAdapter constructor called");
	    }
	    
	    @Override
	    public int getCount() {
	    	System.out.println("got length");
	        return rank.length;
	    }

	    @Override
	    public boolean isViewFromObject(View view, Object object) {
	    	
	    	System.out.println("isViewFromObject executed");
	    	
	    	
	        return view == ((RelativeLayout) object);
	    }

		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			
			    TextView txtrank;
		        TextView txtcountry;
		        TextView txtpopulation;
		        ImageView imgflag;
		        
		        inflater = (LayoutInflater) context
		                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		        View itemView = inflater.inflate(R.layout.viewpager_item, container,
		                false);
		        
		        txtrank = (TextView) itemView.findViewById(R.id.rank);
		        txtcountry = (TextView) itemView.findViewById(R.id.country);
		        txtpopulation = (TextView) itemView.findViewById(R.id.population);
		        
		        txtrank.setText(rank[position]);
		        txtcountry.setText(country[position]);
		        txtpopulation.setText(population[position]);
		        
		        
		        imgflag = (ImageView) itemView.findViewById(R.id.flag);
		        
		        imgflag.setImageResource(flag[position]);
		        
		        (container).addView(itemView);
		        
		        System.out.println("instantiateItem executed");
		        
			return itemView;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
			
			( container).removeView((RelativeLayout) object);
			 System.out.println("destroyItem executed");
		
		}
		
		
		
	    
	    
	 

}
