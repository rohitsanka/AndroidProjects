package com.example.userregistration;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;

public class MySQLiteOpenHelper extends SQLiteOpenHelper {
	
	private static final String DB_NAME = "SAMPLE";
	private static final int VERSION = 1;
	
	public static final String TABLE_NAME = "DATA";
	private static final String COLOUMN_ID= "_id";
	public static final String COLOUMN_DATA="dataUserName";
	public static final String COLOUMN_DATA1="dataPassword";
	public static final String COLOUMN_DATA2="dataUserText";
	
	private static final String CREATE_TABLE = "create table "+TABLE_NAME+"("
			+COLOUMN_ID+" integer primary key autoincrement, "+COLOUMN_DATA+" text,"+COLOUMN_DATA1+" text,"+COLOUMN_DATA2+" text)";

	public MySQLiteOpenHelper(Context context, String name,
			CursorFactory factory, int version) {
		
		super(context, DB_NAME, factory, VERSION);
		
	}

	@Override
	public void onCreate(SQLiteDatabase arg0) {
		arg0.execSQL(CREATE_TABLE);
	}
	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {
	}

}
