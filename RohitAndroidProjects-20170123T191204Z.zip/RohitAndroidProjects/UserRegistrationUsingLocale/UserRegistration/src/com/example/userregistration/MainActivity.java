package com.example.userregistration;

import java.util.ArrayList;
import java.util.Locale;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity  {
	String toast;
	
	private Button registerButton,loginButton;
	
	public static ArrayList<UserDetails> myList = new ArrayList<UserDetails>();
	
	UserDetails user;
	TextView textview,textview2;
	
	final Context context = this;
	
	private EditText editUserName, editPassword;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		setContentView(R.layout.activity_main);
		
		
		registerButton = (Button) findViewById(R.id.btnRegister);
		loginButton = (Button) findViewById(R.id.btnLogin);
		
		registerButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent intent = new Intent(context, ActivityTwo.class);
				String mainValue= "mainActivity";
				intent.putExtra("fromMainActivity", mainValue);
		         startActivity(intent); 
			}
		});
		final Context context = this;
		loginButton.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				
				editUserName= (EditText) findViewById(R.id.txtUname);
				editPassword= (EditText) findViewById(R.id.txtPwd);
				
				String userName = editUserName.getText().toString();
				String password = editPassword.getText().toString();
				
				MySQLiteOpenHelper mySqLiteOpenHelper2 = new MySQLiteOpenHelper(context, null, null, 1);
				SQLiteDatabase sqLiteDatabase2 = mySqLiteOpenHelper2.getReadableDatabase();
				
				Cursor cursor = sqLiteDatabase2.query(MySQLiteOpenHelper.TABLE_NAME, null, null, null, null, null, null);
				
				int flag=0;

				String  dataUserName = null;
				String  dataPassword = null;
				String  dataUserText = null;
				
				myList.clear();
				
				while(cursor.moveToNext())
				{
					user = new UserDetails();
					
					dataUserName = cursor.getString(cursor.getColumnIndex(MySQLiteOpenHelper.COLOUMN_DATA));
					dataPassword =  cursor.getString(cursor.getColumnIndex(MySQLiteOpenHelper.COLOUMN_DATA1));
					dataUserText = cursor.getString(cursor.getColumnIndex(MySQLiteOpenHelper.COLOUMN_DATA2));
					
					user.setUserName(dataUserName);
					user.setPassword(dataPassword);
					user.setUserText(dataUserText);
					
					myList.add(user);
					
				if((userName.equals(dataUserName))&&(password.equals(dataPassword)))
	                    {
					        
					        flag=1;
						}
				}
				
				cursor.close();
		        sqLiteDatabase2.close();
		        
				if(flag==0)
				{
					
					{
						//toast="Invalid Credentials";
						Toast.makeText(getApplicationContext(), R.string.toast,
								   Toast.LENGTH_LONG).show();
					}
				}
				
				else
				{
					Intent intent = new Intent(context,ActivityThree.class);
					intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			        startActivity(intent);
				}
			}
		});
		
		
	}
	
	
	 @Override
	    public boolean onCreateOptionsMenu(Menu menu) {

	        SubMenu langMenu = menu.addSubMenu(0, 200, 2, "Select Language").setIcon(android.R.drawable.ic_menu_rotate);
	            langMenu.add(1, 201, 0, "Fran�ais");
	            langMenu.add(1, 202, 0, "Italiano");
	            langMenu.add(1, 203, 0, "English");

	        return super.onCreateOptionsMenu(menu);
	    }

	    @Override
	    public boolean onOptionsItemSelected(MenuItem item) {
	        switch(item.getItemId()){

	        case 201:

	        	
	            Locale locale = new Locale("fr"); 
	            Locale.setDefault(locale);
	            Configuration config = new Configuration();
	            config.locale = locale;
	            getBaseContext().getResources().updateConfiguration(config, getBaseContext().getResources().getDisplayMetrics());
	            Toast.makeText(this, "Locale in French !", Toast.LENGTH_LONG).show();
	        	
	        	String userName = getResources().getString(R.string.userName);
	        	String password = getResources().getString(R.string.password);
	        	String login = getResources().getString(R.string.Login);
	        	String newUser = getResources().getString(R.string.NewUser);
	        	
	        	
		    	textview = (TextView) findViewById(R.id.TextView01);
		    	textview2 = (TextView) findViewById(R.id.TextView02);
		    	textview2.setText(password);
		    	textview.setText(userName);
		    	registerButton = (Button) findViewById(R.id.btnRegister);
				loginButton = (Button) findViewById(R.id.btnLogin);
				loginButton.setText(login);
				registerButton.setText(newUser);
				
	            break;

	        case 202:

	            Locale locale2 = new Locale("it"); 
	            Locale.setDefault(locale2);
	            Configuration config2 = new Configuration();
	            config2.locale = locale2;
	            getBaseContext().getResources().updateConfiguration(config2, getBaseContext().getResources().getDisplayMetrics());

	            Toast.makeText(this, "Locale in Italian !", Toast.LENGTH_LONG).show();
	            
	            String userName1 = getResources().getString(R.string.userName);
	        	String password1 = getResources().getString(R.string.password);
	        	String login1 = getResources().getString(R.string.Login);
	        	String newUser1 = getResources().getString(R.string.NewUser);
	        	
	        	
		    	textview = (TextView) findViewById(R.id.TextView01);
		    	textview2 = (TextView) findViewById(R.id.TextView02);
		    	textview2.setText(password1);
		    	textview.setText(userName1);
		    	registerButton = (Button) findViewById(R.id.btnRegister);
				loginButton = (Button) findViewById(R.id.btnLogin);
				loginButton.setText(login1);
				registerButton.setText(newUser1);
			
	            break;  
	            
	        case 203:

	            Locale locale3 = new Locale(""); 
	            Locale.setDefault(locale3);
	            Configuration config3 = new Configuration();
	            config3.locale = locale3;
	            getBaseContext().getResources().updateConfiguration(config3, getBaseContext().getResources().getDisplayMetrics());

	            Toast.makeText(this, "Locale in English !", Toast.LENGTH_LONG).show();
	            
	            String userName2 = getResources().getString(R.string.userName);
	        	String password2 = getResources().getString(R.string.password);
	        	String login2 = getResources().getString(R.string.Login);
	        	String newUser2 = getResources().getString(R.string.NewUser);
	        	
	        	
		    	textview = (TextView) findViewById(R.id.TextView01);
		    	textview2 = (TextView) findViewById(R.id.TextView02);
		    	textview2.setText(password2);
		    	textview.setText(userName2);
		    	registerButton = (Button) findViewById(R.id.btnRegister);
				loginButton = (Button) findViewById(R.id.btnLogin);
				loginButton.setText(login2);
				registerButton.setText(newUser2);
			
	            break;  

	        }
	        return super.onOptionsItemSelected(item);
	    }

}
