package com.example.userregistration;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class ActivityFour extends Activity implements OnClickListener{
	
	private TextView textView,textView1,textView2;
	private Button button;
	
	private String userName;
	private String password;
	private String userText;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		setContentView(R.layout.activity_four);
		super.onCreate(savedInstanceState);
		
		textView =  (TextView) findViewById(R.id.TextView40);
		textView1 = (TextView) findViewById(R.id.TextView41);
		textView2 = (TextView) findViewById(R.id.TextView42);
		
		userName= getIntent().getStringExtra("userName");
		password= getIntent().getStringExtra("password");
		userText= getIntent().getStringExtra("userText");
		 
		String passedUserName= userName;
		String passedPassword= password;
		String passedUserText= userText;
		
		textView.setText(passedUserName);
		textView1.setText(passedPassword);
		textView2.setText(passedUserText);
		
		button = (Button) findViewById(R.id.btnEditDetails);
		button.setOnClickListener(this);
		}

	@Override
	public void onClick(View v) {
		Intent intent = new Intent(this, ActivityTwo.class);
		intent.putExtra("userName", userName);
		intent.putExtra("password", password);
		intent.putExtra("userText", userText);
		intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		startActivity(intent);
	}
		
	}






