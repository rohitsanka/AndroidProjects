package com.example.userregistration;

import java.util.ArrayList;

import android.app.Activity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import android.widget.Toast;

public class ActivityThree extends Activity {
	private ListView listView;
	Context context=this;
	final ArrayList<UserDetails> arrayList = new ArrayList<UserDetails>();
	private String toast3;
		
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		setContentView(R.layout.activity_three);
		
		super.onCreate(savedInstanceState);
		
		listView = (ListView) findViewById(R.id.listView);
		
		for(int i=0;i<MainActivity.myList.size();i++)
		{
			arrayList.add(MainActivity.myList.get(i));
		
		}
		MyAdapter myAdapter = new MyAdapter(this,arrayList);
		
		listView.setAdapter(myAdapter);
		
		registerForContextMenu(listView); 
		
	    listView.setOnItemClickListener(new OnItemClickListener() {

		@Override
		public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
				long arg3) {
			
		UserDetails user = arrayList.get(arg2);
		Intent intent = new Intent(context,ActivityFour.class);
		
		intent.putExtra("userName", user.getUserName());
		intent.putExtra("password", user.getPassword());
		intent.putExtra("userText", user.getUserText());
		startActivity(intent);
	}
	});
	}

		public boolean onCreateOptionsMenu(Menu menu)
		    {
		        MenuInflater menuInflater = getMenuInflater();
		        menuInflater.inflate(R.layout.menu, menu);
		        return true;
		    }
			
			
			 public boolean onOptionsItemSelected(MenuItem item)
			    {
			        switch (item.getItemId())
			        {
			        case R.id.menu_logout:
			        	Intent intent = new Intent(this, MainActivity.class);
			        	intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			        	startActivity(intent);
			      default:
			            return super.onOptionsItemSelected(item);
			        }
			    }
			@Override
			public void onCreateContextMenu(ContextMenu menu, View v,
					ContextMenuInfo menuInfo) {
				super.onCreateContextMenu(menu, v, menuInfo);
				
				MenuInflater m = getMenuInflater();  
		        m.inflate(R.menu.context, menu);
			}
			@Override
			public boolean onContextItemSelected(MenuItem item) {
				
				switch(item.getItemId()){  
	             case R.id.delete_item:  
	                  AdapterContextMenuInfo info = (AdapterContextMenuInfo) item.getMenuInfo();
	                  int position;
	                  position = (int) info.id;  
	                  UserDetails user = new UserDetails();
	                  user = arrayList.get(position);
	                  String userName = user.getUserName();
	                  MySQLiteOpenHelper mySQLiteOpenHelper = new MySQLiteOpenHelper(this, null, null, 1);
	  				  SQLiteDatabase sqLiteDatabase = mySQLiteOpenHelper.getWritableDatabase();
	  				
	  				String query = "DELETE FROM '"+MySQLiteOpenHelper.TABLE_NAME+"'WHERE dataUserName='"+userName+"'";
	  				System.out.println(query);
	  				sqLiteDatabase.execSQL(query);
	  				mySQLiteOpenHelper.close();
	  				sqLiteDatabase.close();
	  				
	  				Toast.makeText(getApplicationContext(), R.string.toast3,
							   Toast.LENGTH_LONG).show();
	  				arrayList.remove(position);
	  				MainActivity.myList.remove(position);
	  				Intent intent = new Intent(this, ActivityThree.class);
	  				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
	  				startActivity(intent);
	                 
	                  return true;  
	        }
				return super.onContextItemSelected(item);
			}
			}

