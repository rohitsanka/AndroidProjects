package com.example.userregistration;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MyAdapter extends BaseAdapter {
	
	private ArrayList<UserDetails> objects;
	private LayoutInflater layoutInflater;

	public MyAdapter(Context context, List<UserDetails> objects) {
		super();
		this.objects= (ArrayList<UserDetails>) objects;
		layoutInflater=(LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		
		if(convertView==null)
		{
			convertView=layoutInflater.inflate(R.layout.list_item, null);
			
			TextView userName = (TextView) convertView.findViewById(R.id.listTextView);
			TextView password = (TextView) convertView.findViewById(R.id.listTextView2);
			TextView userText = (TextView) convertView.findViewById(R.id.listTextView3);
			
			userName.setText(objects.get(position).getUserName());
			password.setText(objects.get(position).getPassword());
			userText.setText(objects.get(position).getUserText());
			
		}
		return convertView;
	}

	@Override
	public int getCount() {
		if(objects != null){
			return objects.size();
		}
		else{
			return 0;
		}
	}

	@Override
	public Object getItem(int arg0) {
		
		return objects.get(arg0);
	}

	@Override
	public long getItemId(int arg0) {
		
		return arg0;
	}

}
