package com.example.userregistration;

import com.example.userregistration.R.string;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class ActivityTwo extends Activity {
	
	private EditText editTextUserName, editTextPassword,editUserText ;
	private TextView textUserName, textPassword,textDetails;
	private String userName, password,userText;
	
	private String newUserText;
	private String newPassword;
	private String newUserName;
	private String toast1;
		
		
	
	private Button buttonSave,buttonUpdate,buttonDetails,buttonLogin;
	
	private String value="value";

	final Context context = this;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		
		setContentView(R.layout.activity_two);
		super.onCreate(savedInstanceState);
		
		editTextUserName = (EditText) findViewById(R.id.txtUname20);
		editTextPassword = (EditText) findViewById(R.id.txtPwd20);
		editUserText = (EditText) findViewById(R.id.userTextValue);
		textUserName = (TextView) findViewById(R.id.textUserName);
		textPassword = (TextView) findViewById(R.id.textPassword);
		textDetails = (TextView) findViewById(R.id.textuserText);
		
		userName= getIntent().getStringExtra("userName");
		password= getIntent().getStringExtra("password");
		userText= getIntent().getStringExtra("userText");
		
		value=getIntent().getStringExtra("fromMainActivity");
		
		editTextUserName.setText(userName);
		editTextPassword.setText(password);
		editUserText.setText(userText);
		
		buttonSave = (Button) findViewById(R.id.btnSave);
		buttonUpdate=(Button) findViewById(R.id.update);
		buttonDetails=(Button) findViewById(R.id.btnDetails);
		buttonLogin=(Button) findViewById(R.id.btnLogin2);
		
		if(value!=null)
		{
			buttonUpdate.setVisibility(View.GONE);
			buttonSave.setVisibility(View.VISIBLE);
		}
		
		else
		{
			buttonUpdate.setVisibility(View.VISIBLE);
			buttonSave.setVisibility(View.GONE);
			buttonDetails.setVisibility(View.GONE);
			buttonLogin.setVisibility(View.GONE);
			
		}
	}
	
	public void onClick(View view)
	{
		switch(view.getId()){
		
		case R.id.btnSave:
		
			MySQLiteOpenHelper mySQLiteOpenHelper = new MySQLiteOpenHelper(this, null, null, 1);
			SQLiteDatabase sqLiteDatabase = mySQLiteOpenHelper.getWritableDatabase();
			String query= "insert into "+MySQLiteOpenHelper.TABLE_NAME+"("+MySQLiteOpenHelper.COLOUMN_DATA+","+MySQLiteOpenHelper.COLOUMN_DATA1+","+MySQLiteOpenHelper.COLOUMN_DATA2+") values('"+editTextUserName.getText().toString()+"','"+editTextPassword.getText().toString()+"','"+editUserText.getText().toString()+"')";
			sqLiteDatabase.execSQL(query);
			sqLiteDatabase.close();
			
			editTextUserName.setText(null);
			editTextPassword.setText(null);
			editUserText.setText(null);
			
			Toast.makeText(getApplicationContext(), R.string.toast1,
					   Toast.LENGTH_LONG).show();
			break;
			
		case R.id.btnDetails:
			
			MySQLiteOpenHelper mySQLiteOpenHelper1 = new MySQLiteOpenHelper(this, null, null, 0);
			SQLiteDatabase sqLiteDatabase1 = mySQLiteOpenHelper1.getReadableDatabase();
			Cursor cursor = sqLiteDatabase1.query(MySQLiteOpenHelper.TABLE_NAME, null, null, null, null, null, null);
			
			cursor.moveToFirst();
			while(cursor.isAfterLast()==false)
			{
			
			String  dataUserName = cursor.getString(cursor.getColumnIndex(MySQLiteOpenHelper.COLOUMN_DATA));
			String dataPassword =  cursor.getString(cursor.getColumnIndex(MySQLiteOpenHelper.COLOUMN_DATA1));
			String dataUserText =  cursor.getString(cursor.getColumnIndex(MySQLiteOpenHelper.COLOUMN_DATA2));
			
			textUserName.setText(dataUserName);
			textPassword.setText(dataPassword);
			textDetails.setText(dataUserText);
			cursor.moveToNext();
			}
			cursor.close();
			sqLiteDatabase1.close();
			break;
			
		case R.id.btnLogin2:
			
			Intent intent = new Intent(context,MainActivity.class);
			startActivity(intent);
			break;
			
		case R.id.update:
			
			MySQLiteOpenHelper mySQLiteOpenHelper2 = new MySQLiteOpenHelper(this, null, null, 1);
			SQLiteDatabase sqLiteDatabase2 = mySQLiteOpenHelper2.getWritableDatabase();
			
			newUserName = editTextUserName.getText().toString();
			newPassword = editTextPassword.getText().toString();
			newUserText = editUserText.getText().toString();
			
			String query2="UPDATE "+MySQLiteOpenHelper.TABLE_NAME+" set dataUserName='"+newUserName+"',dataPassword='"+newPassword+"',dataUserText='"+newUserText+"' where dataUserName like '"+userName+"'";
			System.out.println(query2);
			sqLiteDatabase2.execSQL(query2);
			sqLiteDatabase2.close();
			
			editTextUserName.setText(null);
			editTextPassword.setText(null);
			editUserText.setText(null);
			
			for(int i=0;i<MainActivity.myList.size();i++)
			{
				if(userName.equals(MainActivity.myList.get(i).getUserName()))
				{
					MainActivity.myList.get(i).setUserName(newUserName);
					MainActivity.myList.get(i).setPassword(newPassword);
					MainActivity.myList.get(i).setUserText(newUserText);
				}
			}
			
			Toast.makeText(getApplicationContext(), R.string.toast1,
					   Toast.LENGTH_LONG).show();
			
			Intent intent2 = new Intent(context, ActivityThree.class);
			intent2.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			startActivity(intent2);
		
			break;
			
			default:
				
				break;
				
				}
	}

}
