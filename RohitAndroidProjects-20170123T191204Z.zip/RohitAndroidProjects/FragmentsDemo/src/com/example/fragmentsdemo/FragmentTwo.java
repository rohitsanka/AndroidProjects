package com.example.fragmentsdemo;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class FragmentTwo extends Fragment {

	private TextView textView;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view = inflater.inflate(R.layout.fragment_two, null);
		textView = (TextView) view.findViewById(R.id.textView);
		Bundle data = getArguments();
		if(null != data){
			String value = data.getString("value");
			String radioVal = data.getString("radioVal");
			String checkVal = data.getString("checkVal");
			textView.setText(value+"\n\n"+radioVal+"\n\n"+checkVal);
		}
		return view;
	}

	public void updateUserSelectedValue(String value, String radioVal, String checkVal){
		textView.setText(value+"\n\n"+radioVal+"\n\n"+checkVal);
	}
}
