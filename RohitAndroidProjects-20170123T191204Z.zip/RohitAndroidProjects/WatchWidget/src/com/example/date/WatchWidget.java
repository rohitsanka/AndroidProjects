package com.example.date;


import java.text.DateFormat;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;





import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;

import android.widget.DigitalClock;
import android.widget.RemoteViews;

public class WatchWidget extends AppWidgetProvider
{
    /*@Override
    public void onUpdate( Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds )
    {
        RemoteViews remoteViews;
        ComponentName watchWidget;
        DateFormat format = SimpleDateFormat.getTimeInstance( SimpleDateFormat.MEDIUM, Locale.getDefault() );

        remoteViews = new RemoteViews( context.getPackageName(), R.layout.activity_main );
        watchWidget = new ComponentName( context, WatchWidget.class );
    

        remoteViews.setTextViewText( R.id.text, "Time = " + format.format( new Date()));
       //  remoteViews.setTextViewText( R.id.widget_textview, "hi this is uday widget" );
        appWidgetManager.updateAppWidget( watchWidget, remoteViews );
 
      
    }*/
	
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
			int[] appWidgetIds) {
		ComponentName thisWidget = new ComponentName(context,
				WatchWidget.class);

		for (int widgetId : appWidgetManager.getAppWidgetIds(thisWidget)) {

			//Get the remote views
			RemoteViews remoteViews = new RemoteViews(context.getPackageName(),
					R.layout.activity_main);
			// Set the text with the current time.
			remoteViews.setTextViewText(R.id.text, Utility.getCurrentTime("hh:mm:ss a"));
			appWidgetManager.updateAppWidget(widgetId, remoteViews);
		}
	}

    /*@Override
    public void onReceive(Context context, Intent intent) {
        AppWidgetManager appWidgetManager = AppWidgetManager.getInstance(context.getApplicationContext());
        ComponentName thisWidget = new ComponentName(context.getApplicationContext(), WatchWidget.class);
        int[] appWidgetIds = appWidgetManager.getAppWidgetIds(thisWidget);
      if (appWidgetIds != null && appWidgetIds.length > 0) {
            onUpdate(context, appWidgetManager, appWidgetIds);
       }
    }*/
}
