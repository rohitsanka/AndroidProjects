package com.example.jsonexample;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity {
	private ListView listView;

	String myjsonstring;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		

		// Preparing TextView to display JSON results
		//TextView tvResult = (TextView) findViewById(R.id.tvResult);
		listView = (ListView) findViewById(R.id.listView);

		// Reading text file from assets folder
		StringBuffer sb = new StringBuffer();
		BufferedReader br = null;
	
		try {
			AssetManager assetManager = getAssets();
			
			InputStream inputStream ;
			inputStream = assetManager.open("json21.txt");
			InputStreamReader reader = new InputStreamReader(inputStream);
			br = new BufferedReader(reader);
			String temp;
			
			while ((temp = br.readLine()) != null)
				sb.append(temp);
			
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				br.close(); // stop reading
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		myjsonstring = sb.toString(); 

		// Try to parse JSON
		try {
			// Creating JSONObject from String
			JSONObject jsonObjMain = new JSONObject(myjsonstring);
			
			// Creating JSONArray from JSONObject
			
			JSONArray jsonArray = jsonObjMain.getJSONObject("catalog").getJSONArray("book");
			List<JSONObject> list = null ;
			JSONObject jsonObj = new JSONObject();

			// JSONArray has some JSONObject
			for (int i = 0; i < jsonArray.length()+1; i++) {

				// Creating JSONObject from JSONArray
				jsonObj = jsonArray.getJSONObject(i);
				 
				list.add(jsonObj);
				// Getting data from individual JSONObject
				
				/*String id = jsonObj.getString("id");
				String author = jsonObj.getString("author");
				String title = jsonObj.getString("title");
				String genre = jsonObj.getString("genre");
				double price = jsonObj.getDouble("price");
				String publish_date = jsonObj.getString("publish_date");
				String description = jsonObj.getString("description");*/
				

				// Append result to TextView
				/*tvResult.append("ID : " + id + "\n");
				tvResult.append("author : " + author + "\n");
				tvResult.append("title : " + title + "\n");
				tvResult.append("genre : " + genre + "\n");
				tvResult.append("publish_date : " + publish_date + "\n");
				tvResult.append("description : " + description + "\n");
				
				tvResult.append("price : " + Double.toString(price) + "\n\n");*/
				

			}
			ArrayAdapter<JSONObject> adapter = new ArrayAdapter<JSONObject>(this, R.layout.list_item, list) ;
			listView.setAdapter(adapter);

		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
}
