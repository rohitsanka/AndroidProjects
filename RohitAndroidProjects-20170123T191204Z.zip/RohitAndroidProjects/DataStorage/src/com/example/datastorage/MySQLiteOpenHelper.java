package com.example.datastorage;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MySQLiteOpenHelper extends SQLiteOpenHelper {

	private static final String DB_NAME = "SAMPLE";
	private static final int VERSION = 1;
	
	public static final String TABLE_NAME = "DATA";
	private static final String COLUMN_ID = "_id";
	public static final String COLUMN_DATA = "data";
	
	private static final String CREATE_TABLE = "create table "+TABLE_NAME+"("
	+COLUMN_ID+" integer primary key autoincrement, "+COLUMN_DATA+" text)";
	private static final String TAG = "MySQLiteOpenHelper";
	
	public MySQLiteOpenHelper(Context context, String name,
			CursorFactory factory, int version) {
		super(context, DB_NAME, factory, VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase arg0) {
		Log.d(TAG, "--CREATE_TABLE="+CREATE_TABLE);
		arg0.execSQL(CREATE_TABLE);
	}

	@Override
	public void onUpgrade(SQLiteDatabase arg0, int arg1, int arg2) {

	}

}
