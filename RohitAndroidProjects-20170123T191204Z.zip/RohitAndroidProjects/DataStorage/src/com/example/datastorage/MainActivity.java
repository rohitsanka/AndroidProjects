package com.example.datastorage;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	private static final String TAG = "MainActivity";
	private EditText editTextPref;
	private TextView textPref;
	private final String SHARED_PREF_NAME = "pref";
	private final String FILE_NAME = "data.txt";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		editTextPref = (EditText)findViewById(R.id.editTextPref);
		textPref = (TextView)findViewById(R.id.textPref);
	}

	public void onClick(View view){
		switch(view.getId()){
		case R.id.buttonStoreDataIntoPref:
			/*SharedPreferences pref = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);
			SharedPreferences.Editor editor = pref.edit();
			editor.putString("data", editTextPref.getText().toString());
			editor.commit();*/
			/*FileOutputStream fos = null;
			try {
				fos = openFileOutput(FILE_NAME, MODE_PRIVATE);
				fos.write(editTextPref.getText().toString().getBytes());
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally{
				if(fos != null){
					try {
						fos.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}*/
			
			/*File file = new File(Environment.getExternalStorageDirectory(),FILE_NAME);
			Log.d(TAG, "--path="+file.getAbsolutePath());
			FileOutputStream fos = null;
			try {
				fos = new FileOutputStream(file);
				fos.write(editTextPref.getText().toString().getBytes());
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}finally{
				if(fos != null){
					try {
						fos.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}*/
			
			MySQLiteOpenHelper mySQLiteOpenHelper = new MySQLiteOpenHelper(this, null, null, 1);
			SQLiteDatabase sqLiteDatabase = mySQLiteOpenHelper.getWritableDatabase();
			String query = "insert into "+MySQLiteOpenHelper.TABLE_NAME+"("+MySQLiteOpenHelper.COLUMN_DATA+") values('"+editTextPref.getText().toString()+"')";
			Log.d(TAG, "--insert query="+query);
			sqLiteDatabase.execSQL(query);
			sqLiteDatabase.close();
			break;
		case R.id.buttonGetDataFromPref:
			/*SharedPreferences pref1 = getSharedPreferences(SHARED_PREF_NAME, MODE_PRIVATE);
			String data = pref1.getString("data","No data available");
			textPref.setText(data);*/
			/*FileInputStream fis = null;
			try {
				fis = openFileInput(FILE_NAME);
				byte[] data = new byte[1024];
				fis.read(data);
				String dataStr = new String(data);
				textPref.setText(dataStr);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			finally{
				if(fis != null){
					try {
						fis.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}*/

			/*File file1 = new File(Environment.getExternalStorageDirectory(),FILE_NAME);
			Log.d(TAG, "--path="+file1.getAbsolutePath());
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file1);
				byte[] data = new byte[1024];
				fis.read(data);
				String dataStr = new String(data);
				textPref.setText(dataStr);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}finally{
				if(fis != null){
					try {
						fis.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			break;*/
			MySQLiteOpenHelper mySQLiteOpenHelper1 = new MySQLiteOpenHelper(this, null, null, 1);
			SQLiteDatabase sqLiteDatabase1 = mySQLiteOpenHelper1.getReadableDatabase();
			Cursor cursor = sqLiteDatabase1.query(MySQLiteOpenHelper.TABLE_NAME, null, null, null, null, null, null);
			cursor.moveToFirst();
			String data = cursor.getString(cursor.getColumnIndex(MySQLiteOpenHelper.COLUMN_DATA));
			textPref.setText(data);
			cursor.close();
			sqLiteDatabase1.close();
		default:
			break;
		}
	}

}
