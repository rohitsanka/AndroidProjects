package com.example.user.tabnavigator;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by USER on 05-03-2016.
 */
public class Tab3Fragment extends Fragment {
    private View view;
    private TextView message,game;
    private String player,gameName;
    private CheckBox checkBox;
    private Button button;
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        player=getArguments().getString("player");
        gameName=getArguments().getString("gameName");
        view=inflater.inflate(R.layout.tab3, container, false);
        message=(TextView)view.findViewById(R.id.message);
        game=(TextView)view.findViewById(R.id.game);
        checkBox=(CheckBox)view.findViewById(R.id.checkBox);
        button=(Button)view.findViewById(R.id.register);
        message.setText("Hi "+player+"!");
        game.setText("You have been successfully registered for "+gameName+".");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FileOutputStream fos;
                if (checkBox.isChecked()) {

                    try {
                        fos = new FileOutputStream("/sdcard/games.txt", false);


                        FileWriter fWriter;

                        try {
                            fWriter = new FileWriter(fos.getFD());
                            fWriter.write(gameName);
                            fWriter.close();
                        } finally {
                            fos.getFD().sync();
                            fos.flush();
                            fos.close();
                        }
          /*  FileWriter fileWriter = new FileWriter("tab1.txt");
            PrintWriter printWriter=new PrintWriter(fileWriter);
            printWriter.println("Hello");

            printWriter.close();*/

                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    getActivity().finish();
                    System.exit(0);
                }
                else{
                    Toast.makeText(getActivity(), "Please agree to the terms and conditions " , Toast.LENGTH_SHORT).show();

                }
            }



        });
        return view;
    }
    public void register(View view){
        FileOutputStream fos ;

        try  {
            fos = new FileOutputStream("/sdcard/games.txt", false);


            FileWriter fWriter;

            try {
                fWriter = new FileWriter(fos.getFD());
                fWriter.write(gameName);
                fWriter.close();
            }finally {
                fos.getFD().sync();
                fos.flush();
                fos.close();
            }
          /*  FileWriter fileWriter = new FileWriter("tab1.txt");
            PrintWriter printWriter=new PrintWriter(fileWriter);
            printWriter.println("Hello");

            printWriter.close();*/

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        getActivity().finish();
        System.exit(0);
    }
}
