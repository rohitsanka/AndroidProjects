package com.example.user.tabnavigator;

import android.app.DatePickerDialog;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

/**
 * Created by USER on 05-03-2016.
 */
public class Tab2Fragment extends Fragment implements View.OnClickListener {
    private EditText editText2,editText1;
    private SimpleDateFormat dateFormatter;
    private DatePickerDialog datePickerDialog;
    private TextView textView;
    private Button button;
    private Tab2toTab3 tab2toTab3;
    private String game;
    interface Tab2toTab3{
        public void fromTab2toTab3(String player);
    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view;
        view =  inflater.inflate(R.layout.tab2, container, false);
        game=getArguments().getString("game");
        editText1 = (EditText) view.findViewById(R.id.textView1);
        textView=(TextView)view.findViewById(R.id.textView);
        button=(Button)view.findViewById(R.id.button);

        textView.setText(game+" "+"Registration");


        dateFormatter = new SimpleDateFormat("dd-MM-yyyy", Locale.US);

        editText2 = (EditText) view.findViewById(R.id.textView2);
        setDateTimeField();
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String edtext=editText1.getText().toString();
                if ( edtext.equalsIgnoreCase("") ) {
                    Toast.makeText(getActivity(), "Please enter the name before you proceed " , Toast.LENGTH_SHORT).show();

                    // do something

                } else{
                    if (getActivity() instanceof Tab2toTab3) {
                        tab2toTab3 = (Tab2toTab3) getActivity();
                    } else {
                        throw new ClassCastException();
                    }
                    tab2toTab3.fromTab2toTab3(editText1.getText().toString());                }
            }
        });

        return view;

    }



    private void setDateTimeField(){
        editText2.setOnClickListener(this);
        Calendar newCalendar = Calendar.getInstance();
        datePickerDialog = new DatePickerDialog(getActivity(), new DatePickerDialog.OnDateSetListener() {

            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                editText2.setText(dateFormatter.format(newDate.getTime()));
            }

        },newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));



    }



    public void onClick(View view) {
        if(view == editText2) {
            datePickerDialog.show();
        }
    }

    public void saver(View v) {
        if(getActivity() instanceof Tab2toTab3)
        {
            tab2toTab3=(Tab2toTab3)getActivity();
        }else{
            throw new ClassCastException();
        }
        tab2toTab3.fromTab2toTab3(editText1.getText().toString());
    }
    public void b_updateText(String textPassToB) {
        String x=textPassToB;
    }
}
