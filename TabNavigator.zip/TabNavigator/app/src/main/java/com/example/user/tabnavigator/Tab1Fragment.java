package com.example.user.tabnavigator;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.ListFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * Created by USER on 05-03-2016.
 */
public class Tab1Fragment extends ListFragment implements AdapterView.OnItemClickListener {
    String[] games;
    private Tab1toTab2 tab1toTab2;
    interface Tab1toTab2{
        public void fromTab1toTab2(String game);
    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        games=new String[]{"Cricket","Soccer","Basket Ball"};
        return (LinearLayout) inflater.inflate(R.layout.tab1, container, false);
    }

    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,games);
        setListAdapter(adapter);
        getListView().setOnItemClickListener(this);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Toast.makeText(getActivity(), "Item: " +games[position] , Toast.LENGTH_SHORT).show();
        if(getActivity() instanceof Tab1toTab2)
        {
            tab1toTab2=(Tab1toTab2)getActivity();
        }else{
            throw new ClassCastException();
        }
     tab1toTab2.fromTab1toTab2(games[position]);




    }



}

